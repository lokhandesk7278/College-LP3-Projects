public class Student {

    private String name;
    private int rollNo;

    public void registerCourse(Course course) {
        course.addStudent(this);
    }
}
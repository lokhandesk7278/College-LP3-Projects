public class Course {

    private String courseName;

    public void addStudent(Student student) {
        System.out.println("Student added");
    }
}
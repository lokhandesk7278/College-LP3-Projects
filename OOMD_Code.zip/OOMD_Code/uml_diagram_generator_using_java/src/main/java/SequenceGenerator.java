import java.io.*;
import java.util.*;

import com.github.javaparser.ast.*;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.MethodCallExpr;

import net.sourceforge.plantuml.SourceStringReader;

public class SequenceGenerator {

    // ATTRIBUTES
    String yUML;
    String in;
    String out;
    String method;
    String className;

    static HashMap<String, String> methodMapClass;
    static ArrayList<CompilationUnit> compilationunits;
    static HashMap<String, ArrayList<MethodCallExpr>> methodCalls;

    // GETTERS AND SETTERS
    public String getPumlCode() {
        return yUML;
    }

    public void setPumlCode(String pumlCode) {
        this.yUML = pumlCode;
    }

    public String getInPath() {
        return in;
    }

    public void setInPath(String inPath) {
        this.in = inPath;
    }

    public String getOutPath() {
        return out;
    }

    public void setOutPath(String outPath) {
        this.out = outPath;
    }

    public String getInFuncName() {
        return method;
    }

    public void setInFuncName(String inFuncName) {
        this.method = inFuncName;
    }

    public String getInClassName() {
        return className;
    }

    public void setInClassName(String inClassName) {
        this.className = inClassName;
    }

    public static HashMap<String, String> getMapMethodClass() {
        return methodMapClass;
    }

    public static void setMapMethodClass(
            HashMap<String, String> mapMethodClass) {
        SequenceGenerator.methodMapClass = mapMethodClass;
    }

    public static ArrayList<CompilationUnit> getCuArray() {
        return compilationunits;
    }

    public static void setCuArray(
            ArrayList<CompilationUnit> cuArray) {
        SequenceGenerator.compilationunits = cuArray;
    }

    public static HashMap<String, ArrayList<MethodCallExpr>>
    getMapMethodCalls() {
        return methodCalls;
    }

    public static void setMapMethodCalls(
            HashMap<String, ArrayList<MethodCallExpr>> mapMethodCalls) {
        SequenceGenerator.methodCalls = mapMethodCalls;
    }

    SequenceGenerator(String in, String className,
                      String function, String out) {

        this.in = in;
        this.out = in + "/" + out + ".png";
        this.className = className;
        this.method = function;

        methodMapClass = new HashMap<String, String>();
        methodCalls = new HashMap<String, ArrayList<MethodCallExpr>>();

        yUML = "@startuml\n";
    }

    public void start() throws Exception {

        OutputStream png;
        SourceStringReader reader;

        compilationunits = UtilityHelper.getCuArray(in);

        /*
         * STEP 1:
         * Find all classes, methods and method calls.
         */
        for (CompilationUnit compilationUnit : compilationunits) {

            List<TypeDeclaration> typDeclaration =
                    compilationUnit.getTypes();

            for (Node n : typDeclaration) {

                ClassOrInterfaceDeclaration classOrInterface =
                        (ClassOrInterfaceDeclaration) n;

                String currentClass =
                        classOrInterface.getName();

                for (BodyDeclaration bodyDeclaration :
                        ((TypeDeclaration) classOrInterface)
                                .getMembers()) {

                    if (bodyDeclaration instanceof MethodDeclaration) {

                        MethodDeclaration methodDeclaration =
                                (MethodDeclaration) bodyDeclaration;

                        ArrayList<MethodCallExpr>
                                methodCallExpressionList =
                                new ArrayList<MethodCallExpr>();

                        /*
                         * IMPORTANT:
                         * Recursively find method calls.
                         *
                         * This allows us to detect calls inside:
                         * if
                         * else
                         * loops
                         * nested blocks
                         */
                        collectMethodCalls(
                                methodDeclaration,
                                methodCallExpressionList);

                        methodCalls.put(
                                methodDeclaration.getName(),
                                methodCallExpressionList);

                        methodMapClass.put(
                                methodDeclaration.getName(),
                                currentClass);
                    }
                }
            }
        }

        /*
         * Check whether requested method exists.
         */
        if (!methodMapClass.containsKey(method)) {

            System.out.println(
                    "Method not found: " + method);

            return;
        }

        /*
         * The class containing the starting method.
         *
         * IMPORTANT:
         * We use methodMapClass instead of the last class
         * found in the input folder.
         */
        String startingClass =
                methodMapClass.get(method);

        /*
         * STEP 2:
         * Create PlantUML participants.
         */
        yUML = yUML + "actor User\n";

        /*
         * Add all classes only once.
         */
        HashSet<String> classes =
                new HashSet<String>(methodMapClass.values());

        for (String currentClass : classes) {

            yUML = yUML +
                    "participant " +
                    currentClass +
                    "\n";
        }

        yUML = yUML + "\n";

        /*
         * STEP 3:
         * User calls the starting method.
         */
        yUML = yUML +
                "User -> " +
                startingClass +
                " : " +
                method +
                "()\n";

        yUML = yUML +
                "activate " +
                startingClass +
                "\n";

        /*
         * STEP 4:
         * Parse all method calls.
         */
        parse(
                method,
                new HashSet<String>());

        yUML = yUML +
                "deactivate " +
                startingClass +
                "\n";

        yUML = yUML +
                "@enduml";

        /*
         * STEP 5:
         * Generate PNG using PlantUML.
         */
        try {

            png = new FileOutputStream(out);

            reader =
                    new SourceStringReader(yUML);

            reader.generateImage(png);

            png.close();

        } catch (FileNotFoundException e) {

            e.printStackTrace();

        } catch (IOException e) {

            e.printStackTrace();
        }

        /*
         * Display generated PlantUML code.
         */
        System.out.println(
                "Code generated :\n" + yUML);
    }


    /*
     * ---------------------------------------------------------
     * Recursively collect ALL method calls.
     * ---------------------------------------------------------
     */
    private void collectMethodCalls(
            Node node,
            ArrayList<MethodCallExpr> list) {

        /*
         * If this node itself is a method call,
         * add it to the list.
         */
        if (node instanceof MethodCallExpr) {

            list.add(
                    (MethodCallExpr) node);
        }

        /*
         * Visit all children recursively.
         */
        for (Object child :
                node.getChildrenNodes()) {

            if (child instanceof Node) {

                collectMethodCalls(
                        (Node) child,
                        list);
            }
        }
    }


    /*
     * ---------------------------------------------------------
     * Parse method calls recursively.
     * ---------------------------------------------------------
     */
    private void parse(
            String callerMethod,
            HashSet<String> callStack) {

        /*
         * Prevent infinite recursion.
         */
        if (callStack.contains(callerMethod)) {
            return;
        }

        callStack.add(callerMethod);

        ArrayList<MethodCallExpr> calls =
                methodCalls.get(callerMethod);

        if (calls == null) {
            callStack.remove(callerMethod);
            return;
        }

        String classCaller =
                methodMapClass.get(callerMethod);

        /*
         * Process every method call.
         */
        for (MethodCallExpr methodCallExpression :
                calls) {

            String methodCalled =
                    methodCallExpression.getName();

            /*
             * Ignore methods that are not part of
             * our project classes.
             *
             * Example:
             * System.out.println()
             */
            if (!methodMapClass.containsKey(
                    methodCalled)) {

                continue;
            }

            String classCalled =
                    methodMapClass.get(methodCalled);

            /*
             * Don't show a method calling itself.
             */
            if (methodCalled.equals(callerMethod)) {
                continue;
            }

            /*
             * Method call.
             */
            yUML = yUML +
                    classCaller +
                    " -> " +
                    classCalled +
                    " : " +
                    methodCallExpression
                            .toStringWithoutComments() +
                    "\n";

            /*
             * Activate called class.
             */
            yUML = yUML +
                    "activate " +
                    classCalled +
                    "\n";

            /*
             * Follow the called method.
             */
            parse(
                    methodCalled,
                    callStack);

            /*
             * Return arrow.
             */
            yUML = yUML +
                    classCalled +
                    " --> " +
                    classCaller +
                    "\n";

            /*
             * Deactivate called class.
             */
            yUML = yUML +
                    "deactivate " +
                    classCalled +
                    "\n";
        }

        callStack.remove(callerMethod);
    }
}
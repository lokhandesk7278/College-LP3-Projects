import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;


import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import net.sourceforge.plantuml.SourceStringReader;

public class UtilityHelper {
	
	public static String removeDups(String stringInput){
        String[] lines = stringInput.split(",");
        String[] unique = new LinkedHashSet<String>( Arrays.asList(lines)).toArray(new String[0]);
        String res = String.join(",", unique);
        return res;
	} 
	
	public static ArrayList<CompilationUnit> getCuArray(String in) throws Exception {        
        ArrayList<CompilationUnit> cunits = new ArrayList<CompilationUnit>();
        File folder = new File(in);
				
        for ( File f : listOfJavaFiles(folder)) {
            if (f.isFile() && f.getName().endsWith(".java")) {
                FileInputStream streamin = new FileInputStream(f);
                CompilationUnit cUnit;
                try {
                    cUnit = JavaParser.parse(streamin);
                    cunits.add(cUnit);
                } finally {
                    streamin.close();
                }
            }
        }
        return cunits;
    }
	
	public static void buildMapOfIntAndClasses(ArrayList<CompilationUnit> cunits) {
        for (CompilationUnit cu : cunits) {
            List<TypeDeclaration> cl = cu.getTypes();
            for (Node node : cl) {
                ClassOrInterfaceDeclaration coi = (ClassOrInterfaceDeclaration) node;
                ClassGenerator.getClassOrIntMap().put(coi.getName(), coi.isInterface()); // false is class, true is interface                                     
            }
        }
	}
	
	public static File[] listOfJavaFiles(File folder){
		File[] listOfFiles = folder.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String name) {
		    	return name.toLowerCase().endsWith(".java");		        
			}
		});
		
		return listOfFiles;
	}
	
	public static void buildAst(ArrayList<CompilationUnit> cunits){
        for (CompilationUnit cu : cunits) { 
        	ClassGenerator.astree += ClassGenerator.parser(cu); 
        }
	}
	
    public static String bracketChangeMethod(String bracket) {
        bracket = bracket.replace("[", "(");
        bracket = bracket.replace("]", ")");
        bracket = bracket.replace("<", "(");
        bracket = bracket.replace(">", ")");
        return bracket;
    }

    public static String modifyScope(String stringScope) {
       if (stringScope.equals("private"))
    	   return "-";
       else if (stringScope.equals("public"))
    	   return "+";
       else
    	   return "";
    }
	
    public static String parseAdditions() {
        String finalRes = "";
        Set<String> keys = ClassGenerator.mapRelationship.keySet(); // get all keys
        for (String key : keys) {
            String[] classes = key.split("-");
            if (ClassGenerator.classOrIntMap.get(classes[0]))
                finalRes = finalRes + "[<<interface>>;" + classes[0] + "]";
            else
                finalRes = finalRes + "[" + classes[0] + "]";
            finalRes = finalRes + ClassGenerator.mapRelationship.get(key); // Add connection
            if (ClassGenerator.classOrIntMap.get(classes[1]))
                finalRes = finalRes + "[<<interface>>;" + classes[1] + "]";
            else
                finalRes  = finalRes + "[" + classes[1] + "]";
            finalRes += ",";
        }
        return finalRes;
    }
	

    public static void generatePNG(String grammar, String outPath) {

    try {

        // Convert the existing yUML grammar into PlantUML syntax
        String plantUml = convertYumlToPlantUml(grammar);

        System.out.println("\nGenerated PlantUML:");
        System.out.println(plantUml);

        // Create PlantUML reader
        SourceStringReader reader = new SourceStringReader(plantUml);

        // Generate PNG locally
        File outputFile = new File(outPath);

        try (FileOutputStream outputStream = new FileOutputStream(outputFile)) {
            reader.outputImage(outputStream);
        }

        System.out.println(
            "UML diagram successfully generated at: "
            + outputFile.getAbsolutePath()
        );

    } catch (Exception e) {

        System.err.println("Error generating UML diagram:");
        e.printStackTrace();

    }
}
    
    private static String convertYumlToPlantUml(String grammar) {

    StringBuilder plantUml = new StringBuilder();

    plantUml.append("@startuml\n");
    plantUml.append("skinparam classAttributeIconSize 0\n");

    String[] elements = grammar.split(",");

    for (String element : elements) {

        element = element.trim();

        if (element.isEmpty()) {
            continue;
        }

        /*
         * Relationship:
         * [Course] uses -.->[Student]
         */
        if (element.startsWith("[")
                && element.lastIndexOf("[") > 0
                && !element.contains("|")) {

            plantUml.append(convertRelationship(element));
            continue;
        }

        /*
         * Class:
         * [Student|- name : String;- rollNo : int|+ registerCourse(...) : void]
         */
        if (element.startsWith("[") && element.endsWith("]")) {

            plantUml.append(convertClass(element));
        }
    }

    plantUml.append("@enduml\n");

    return plantUml.toString();
}
private static String convertClass(String yumlClass) {

    String content = yumlClass.substring(
            1,
            yumlClass.length() - 1
    );

    String[] parts = content.split("\\|", -1);

    String className = parts[0].trim();

    // Handle interface notation
    boolean isInterface = className.contains("<<interface>>");

    className = className
            .replace("<<interface>>", "")
            .trim();

    StringBuilder result = new StringBuilder();

    if (isInterface) {
        result.append("interface ")
              .append(className)
              .append(" {\n");
    } else {
        result.append("class ")
              .append(className)
              .append(" {\n");
    }

    /*
     * Attributes
     */
    if (parts.length > 1) {

        String[] attributes = parts[1].split(";");

        for (String attribute : attributes) {

            attribute = attribute.trim();

            if (!attribute.isEmpty()) {
                result.append("    ")
                      .append(attribute)
                      .append("\n");
            }
        }
    }

    /*
     * Methods
     */
    if (parts.length > 2) {

        String[] methods = parts[2].split(";");

        for (String method : methods) {

            method = method.trim();

            if (!method.isEmpty()) {
                result.append("    ")
                      .append(method)
                      .append("\n");
            }
        }
    }

    result.append("}\n\n");

    return result.toString();
}
private static String convertRelationship(String relationship) {

    int firstStart = relationship.indexOf("[");
    int firstEnd = relationship.indexOf("]");

    int secondStart = relationship.lastIndexOf("[");
    int secondEnd = relationship.lastIndexOf("]");

    if (firstStart == -1
            || firstEnd == -1
            || secondStart == -1
            || secondEnd == -1
            || firstStart == secondStart) {

        return "";
    }

    String source = relationship.substring(
            firstStart + 1,
            firstEnd
    ).trim();

    String target = relationship.substring(
            secondStart + 1,
            secondEnd
    ).trim();

    String middle = relationship.substring(
            firstEnd + 1,
            secondStart
    ).trim();

    String relation;

    /*
     * Dependency
     * [A] uses -.->[B]
     */
    if (middle.contains("- .->")
            || middle.contains("-.->")) {

        relation = " ..> ";
    }

    /*
     * Implements
     * [A]^-.-[B]
     */
    else if (middle.contains("^-.-")) {

        relation = " ..|> ";
    }

    /*
     * Inheritance
     * [A]^[B]
     */
    else if (middle.contains("^")) {

        relation = " <|-- ";
    }

    /*
     * Composition
     * [A]++->[B]
     */
    else if (middle.contains("++")) {

        relation = " *-- ";
    }

    /*
     * Aggregation
     * [A]<>->[B]
     */
    else if (middle.contains("<>")) {

        relation = " o-- ";
    }

    /*
     * Association
     */
    else {

        relation = " --> ";
    }

    String label = "";

    if (middle.contains("uses")) {
        label = " : uses";
    }

    return source
            + relation
            + target
            + label
            + "\n";
}
    /*
     * import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import org.apache.commons.io.FilenameUtils;

public class Test {
    public static void main(String[] k) throws Exception {
    	    	
    	//String[] args= { "seq", "/Users/akshaymishra/Desktop/tests/uml-sequence-test.zip", "Main", "main", "out"};
    	String[] args= { "class", "/Users/akshaymishra/Desktop/tests/uml-parser-test-4.zip", "out"};
    	String extPath=null,inPath=null;    	
        boolean zipped=false;     		  
        
      	if (FilenameUtils.getExtension(args[1]).equals("zip")){
      		zipped=true;
      		extPath = args[1].substring(0, args[1].lastIndexOf("/"));
      		try {
      	        ZipFile zipFile = new ZipFile(args[1]);
      	        zipFile.extractAll(extPath);
      	    } catch (ZipException e) {
      	        e.printStackTrace();
      	    }
      		
      		inPath = extPath + args[1].substring(args[1].lastIndexOf("/"), args[1].lastIndexOf("."));	
      	}      	
      	
      	if (zipped) {
  	        if (args[0].equals("class")) {
  	            ClassGenerator cp = new ClassGenerator(inPath, args[2]);
  	            cp.start();
  	        } 
  	        else if (args[0].equals("seq")) {
  	        	SequenceGenerator sg = new SequenceGenerator(args[1].substring(0, args[1].indexOf(".")) ,args[2],args[3],args[4]);
  	        	sg.start();
  	        } else{
  	            System.out.println("Invalid keyword " + args[0]);
  	        }
      	}
      	else {
      		if (args[0].equals("class")) {
  	            ClassGenerator cp = new ClassGenerator(args[1], args[2]);
  	            cp.start();
  	        } 
  	        else if (args[0].equals("seq")) {
  	        	SequenceGenerator sg = new SequenceGenerator(args[1] ,args[2],args[3],args[4]);
  	        	sg.start();
  	        } else{
  	            System.out.println("Invalid keyword " + args[0]);
  	        }

      	}      		
    }
}

*/
}

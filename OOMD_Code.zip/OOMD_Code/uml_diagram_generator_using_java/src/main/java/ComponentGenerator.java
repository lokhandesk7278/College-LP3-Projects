import java.io.FileOutputStream;
import java.io.OutputStream;

import net.sourceforge.plantuml.SourceStringReader;

public class ComponentGenerator {

    String in;
    String out;
    String puml;

    ComponentGenerator(String in, String out) {

        this.in = in;
        this.out = in + "/" + out + ".png";

        puml = "@startuml\n";
    }

    public void start() throws Exception {

        /*
         * Component Diagram
         * Student Course Registration System
         */

        puml += "title Student Course Registration System\n\n";

        puml += "component \"Student\" as Student\n";

        puml += "component \"Course\" as Course\n";

        puml += "Student --> Course : registerCourse()\n";

        puml += "Course --> Student : registration result\n";

        puml += "\n";

        puml += "note right of Student\n";
        puml += "Student component\n";
        puml += "Handles course registration\n";
        puml += "end note\n";

        puml += "note right of Course\n";
        puml += "Course component\n";
        puml += "Checks availability\n";
        puml += "Adds student\n";
        puml += "end note\n";

        puml += "@enduml";

        /*
         * Generate PNG
         */
        try (OutputStream png =
                     new FileOutputStream(out)) {

            SourceStringReader reader =
                    new SourceStringReader(puml);

            reader.generateImage(png);
        }

        System.out.println(
                "Component Diagram generated successfully.");

        System.out.println(
                "Code generated:\n" + puml);

        System.out.println(
                "Output: " + out);
    }
}
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import net.sourceforge.plantuml.SourceStringReader;

public class ActivityGenerator {

    String in;
    String out;
    String yUML;

    ActivityGenerator(String in, String out) {

        this.in = in;
        this.out = in + "/" + out + ".png";

        yUML = "@startuml\n";
    }

    public void start() throws Exception {

        /*
         * Activity diagram for:
         *
         * Student.registerCourse()
         *
         * if (course.isAvailable())
         *      course.addStudent(this)
         * else
         *      Course is full
         */

        yUML += "start\n";

        yUML += ":Student selects course;\n";

        yUML += ":Register Course;\n";

        yUML += "if (Is course available?) then (Yes)\n";

        yUML += "    :Add student to course;\n";

        yUML += "    :Display \"Course registered successfully\";\n";

        yUML += "else (No)\n";

        yUML += "    :Display \"Course is full\";\n";

        yUML += "endif\n";

        yUML += "stop\n";

        yUML += "@enduml";

        /*
         * Generate PNG
         */
        try (OutputStream png =
                     new FileOutputStream(out)) {

            SourceStringReader reader =
                    new SourceStringReader(yUML);

            reader.generateImage(png);
        }

        System.out.println(
                "Activity Diagram generated successfully.");

        System.out.println(
                "Code generated:\n" + yUML);

        System.out.println(
                "Output: " + out);
    }
}
error id: file:///D:/stqa/uml_diagram_generator_using_java/src/main/java/SequenceGenerator.java:_empty_/`<any>`#getType#
file:///D:/stqa/uml_diagram_generator_using_java/src/main/java/SequenceGenerator.java
empty definition using pc, found symbol in pc: _empty_/`<any>`#getType#
empty definition using semanticdb
empty definition using fallback
non-local guesses:

offset: 4965
uri: file:///D:/stqa/uml_diagram_generator_using_java/src/main/java/SequenceGenerator.java
text:
```scala
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.nodeTypes.NodeWithType;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import net.sourceforge.plantuml.SourceStringReader;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SequenceGenerator {

    private String in;
    private String out;
    private String className;
    private String method;

    private ArrayList<CompilationUnit> compilationUnits;

    private Map<String, String> variableTypes = new HashMap<>();

    private Set<String> classNames = new HashSet<>();

    private StringBuilder plantUML = new StringBuilder();

    public SequenceGenerator(String in, String className,
                             String function, String out) {

        this.in = in;
        this.out = in + "/" + out + ".png";
        this.className = className;
        this.method = function;
    }

    public void start() throws Exception {

        compilationUnits = UtilityHelper.getCuArray(in);

        // Find all classes in the input folder
        for (CompilationUnit cu : compilationUnits) {

            cu.findAll(com.github.javaparser.ast.body.ClassOrInterfaceDeclaration.class)
                    .forEach(c -> classNames.add(c.getNameAsString()));
        }

        // Find the requested class
        MethodDeclaration targetMethod = null;

        for (CompilationUnit cu : compilationUnits) {

            for (MethodDeclaration md :
                    cu.findAll(MethodDeclaration.class)) {

                if (md.getNameAsString().equals(method)) {

                    String currentClass =
                            md.findAncestor(
                                    com.github.javaparser.ast.body.ClassOrInterfaceDeclaration.class)
                                    .map(c -> c.getNameAsString())
                                    .orElse("");

                    if (currentClass.equals(className)) {
                        targetMethod = md;
                        break;
                    }
                }
            }

            if (targetMethod != null) {
                break;
            }
        }

        if (targetMethod == null) {

            System.out.println(
                    "Method not found: " + className + "." + method);

            return;
        }

        // Find variable types inside the method
        findVariableTypes(targetMethod);

        // Start PlantUML
        plantUML.append("@startuml\n");

        plantUML.append("actor User\n");
        plantUML.append("participant ").append(className).append("\n");

        // Add all classes except the starting class
        for (String name : classNames) {

            if (!name.equals(className)) {
                plantUML.append("participant ")
                        .append(name)
                        .append("\n");
            }
        }

        plantUML.append("\n");

        // User starts the method
        plantUML.append("User -> ")
                .append(className)
                .append(" : ")
                .append(method)
                .append("()\n");

        plantUML.append("activate ")
                .append(className)
                .append("\n");

        // Find all method calls recursively
        MethodCallVisitor visitor =
                new MethodCallVisitor(className);

        visitor.visit(targetMethod, null);

        plantUML.append("\n");

        plantUML.append("deactivate ")
                .append(className)
                .append("\n");

        plantUML.append("@enduml");

        // Generate PNG
        try (OutputStream png =
                     new FileOutputStream(out)) {

            SourceStringReader reader =
                    new SourceStringReader(plantUML.toString());

            reader.generateImage(png);
        }

        System.out.println("Code generated:");
        System.out.println(plantUML);
        System.out.println("Output: " + out);
    }

    /**
     * Find variable types such as:
     *
     * Course course;
     * Course course = new Course();
     */
    private void findVariableTypes(MethodDeclaration methodDeclaration) {

        // Method parameters
        methodDeclaration.getParameters().forEach(parameter -> {

            String variableName =
                    parameter.getNameAsString();

            String type =
                    parameter.getType@@().asString();

            variableTypes.put(variableName, type);
        });

        // Local variables
        methodDeclaration.findAll(VariableDeclarator.class)
                .forEach(variable -> {

                    String variableName =
                            variable.getNameAsString();

                    String type =
                            variable.getType().asString();

                    variableTypes.put(variableName, type);
                });
    }

    /**
     * Visitor that finds method calls anywhere inside
     * the method, including if/else blocks.
     */
    private class MethodCallVisitor
            extends VoidVisitorAdapter<Void> {

        private String callerClass;

        MethodCallVisitor(String callerClass) {
            this.callerClass = callerClass;
        }

        @Override
        public void visit(MethodCallExpr call, Void arg) {

            super.visit(call, arg);

            String methodName =
                    call.getNameAsString();

            // Ignore Java library output calls
            if (methodName.equals("println")
 methodName.equals("print")
 methodName.equals("printf")) {

                return;
            }

            String calledClass = null;

            /*
             * Example:
             *
             * course.isAvailable()
             *
             * scope = course
             */
            if (call.getScope().isPresent()) {

                String scope =
                        call.getScope().get().toString();

                if (variableTypes.containsKey(scope)) {

                    calledClass =
                            variableTypes.get(scope);
                }
            }

            /*
             * If there is no explicit scope,
             * assume it is a method of the current class.
             */
            if (calledClass == null) {
                calledClass = callerClass;
            }

            // Only show calls involving our project classes
            if (!classNames.contains(calledClass)) {
                return;
            }

            /*
             * Don't display the original method call again.
             */
            if (calledClass.equals(callerClass)
                    && methodName.equals(method)) {

                return;
            }

            String arguments =
                    call.getArguments().toString();

            plantUML.append(callerClass)
                    .append(" -> ")
                    .append(calledClass)
                    .append(" : ")
                    .append(methodName)
                    .append("(")
                    .append(arguments.equals("[]")
                            ? ""
                            : arguments.substring(
                                    1,
                                    arguments.length() - 1))
                    .append(")\n");

            /*
             * Return arrow
             */
            plantUML.append(calledClass)
                    .append(" --> ")
                    .append(callerClass)
                    .append("\n");
        }
    }
}
```


#### Short summary: 

empty definition using pc, found symbol in pc: _empty_/`<any>`#getType#